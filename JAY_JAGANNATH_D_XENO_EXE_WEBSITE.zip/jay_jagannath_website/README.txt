JAY JAGANNATH — D.XENO.EXE WEBSITE
=================================

FILES
- index.html: complete responsive website
- assets/jagannath-portrait.jpg: uploaded Lord Jagannath image
- assets/divine-trinity.jpg: uploaded Divine Trinity image
- assets/odia-jagannath-devotional.mp3: your uploaded audio

HOW TO OPEN
1. Extract this ZIP file.
2. Open the jay_jagannath_website folder.
3. Open index.html in a modern browser.

IMPORTANT ABOUT AUDIO
The website attempts autoplay, but many browsers block autoplay with sound.
If sound does not start automatically, tap ENTER WITH JAY JAGANNATH or the
play button in the bottom-right audio player.

HOW TO PUBLISH
Upload the extracted folder contents to a static hosting provider such as
GitHub Pages, Netlify, or Cloudflare Pages. Keep the assets folder beside
index.html so image and audio paths continue to work.

This is a static website; no build step or API key is required.
